﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;

namespace CsharpExcelVeriAktarma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listviewDoldur()
        {
            try
            {
                // 20 tane ürünü dinamik olarak eklemsi için kulandık. artırıp azaltabilirsiniz.
                int urunSayisi = 20;
                // For dönüsü ile ürün sayısı kadar ekleme işlemi yapıyoruz
                for (int i = 0; i < urunSayisi; i++)
                {
                    // eklenecek ürünler için örnek bir dizi tanımlıyoruz
                    string[] urunler = {
                                       "UrunID"+i.ToString(),
                                       "Urun Adı " + i.ToString(),
                                       "Adet :" + i.ToString()
                                   };
                    ListViewItem urun = new ListViewItem(urunler);
                    listView1.Items.Add(urun);
                } // for bitis
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ürün ekleme işlemi sırasında bir hata meydana geldi.\n Hata içeriği:"+ex.ToString());
            }           
        }

        /// <summary>
        ///  ListView verilerini dinamik olarak excel dosyasına aktarır
        /// </summary>
        /// <param name="lw">Aktarım Yapılacak ListView nesnesinin IDsi</param>
        public void excelAktar(ListView lw, ProgressBar pb = null)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application xls = new Microsoft.Office.Interop.Excel.Application();
                Workbook wb = xls.Workbooks.Add(XlSheetType.xlWorksheet);
                Worksheet ws = (Worksheet)xls.ActiveSheet; // çalışma alanı aktif çalışma alanı

                xls.Visible = true; // görünürlük aktif
                #region manuelBaslikalani
                // alanları manuel olarak yazıyoruz
                /*ws.Cells[1, 1] = "Stok Kodu";
                ws.Cells[1, 2] = "Barkod";
                ws.Cells[1, 3] = "Stok Adı";
                ws.Cells[1, 4] = "Stok Miktar";
                ws.Cells[1, 4] = "Stok Grubu";
                ws.Cells[1, 5] = "Stok Markası";
                */
                #endregion
                // Eğer Progress bar nesnesi null değil ise sıfırlama ve ayarlama işlemini gerçekleştir
                if (pb != null)
                {
                    pb.Maximum = Convert.ToInt32(lw.Items.Count.ToString());
                    pb.Value = 0;
                }

                // Şimdi ise dinamik olarak colon bilgilerini alıyoruz ekliyoruz
                for (int i = 0; i < lw.Columns.Count; i++)
                {
                    // alanları manuel olarak yazıyoruz
                    ws.Cells[1, i + 1] = lw.Columns[i].Text.ToString();
                }
                // Şimdi de lw içerisindeki verileri dinamik olarak aktarıyoruz
                int _i = 2; // 2. satırdan itibaren içerikleri doldurmaya başla
                int j = 1;
                foreach (ListViewItem item in lw.Items)
                {
                    ws.Cells[_i, j] = item.Text.ToString();
                    foreach (ListViewItem.ListViewSubItem subitem in item.SubItems)
                    {
                        ws.Cells[_i, j] = subitem.Text.ToString();
                        j++;
                    }
                    j = 1;
                    _i++;
                    // Eğer Progress bar nesnesi null değil ise artırma işlemini yap
                    if (pb != null)
                    {
                        pb.Value = _i - 2;
                    }

                }
                xls.Columns.AutoFit(); // column sütunları yazı boyutuna göre ayarlıyor
                xls.AlertBeforeOverwriting = false; // aktarama işlemi sırasında alabileceğimiz hatalara karşı önlem olarak hata bastırma işlemi yapılıyor
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listviewDoldur();
        }

        private void btnAktar_Click(object sender, EventArgs e)
        {
            excelAktar(listView1);
        }
    }
}
